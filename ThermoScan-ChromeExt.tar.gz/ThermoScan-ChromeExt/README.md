# Chrome Extension for ThermoScan WebServer
Emidio Capriotti - University of Bologna (Italy)


The Extension allow to send the content of a PMC web page displayed by Google Chrome 
to the ThermoScan WebServer ([https://folding.biofold.org/thermoscan](https://folding.biofold.org/thermoscan))
